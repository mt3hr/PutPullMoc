
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>学生情報削除</title>
<header>

</header>
    <a href="11MenuK.html"><img src="./img/PutPullMoc.png" alt="メニュー"></a>
    <div id="nav">
        <table>
            <th><a href="11MenuK.php">メニュー</a></th>
            <th><a href="11MenuK.html">学生一覧</a></th>
            <th><a href="11MenuK.html">保存一覧</a></th>
            <th><a href="11MenuK.html">新規作成</a></th>
        </table>
        <button type="button" onclick="location.href='10login.html'">ログアウト</button>
    </div>
</head>
<body> 
    <h2>学生情報削除</h2>
    <p>削除しました。</p>
    <form action="24studentSearch.php">
        <input type="submit" value ="戻る">
    </form>
</body>
</html>