<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>パスワードリセット</title>
    <link href="css/login.css" rel="stylesheet" type="text/css" media="all">
</head>

<body>
    <div class="login-page">
        <div class="form">
            <h1>パスワードリセット</h1>
            <p>パスワードをリセットしました</p>
            <form method="POST" action="./index.php">
                <input class="button" type="submit" name="submit" value="ログインへ">
            </form>
        </div>
    </div>
</body>

</html>