-- DROP TABLE passwordReset;
-- CREATE TABLE passwordReset (
--  Email CHAR(36) NOT NULL,
--  token CHAR(36) NOT NULL,
--  ResetSentAt CHAR(50) NOT NULL

-- );
SELECT * FROM userTable;